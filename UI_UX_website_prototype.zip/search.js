const articles = [
      { title: "JavaScriptの基礎", content: "変数、関数、DOM操作について学びます。" },
      { title: "HTMLとCSSの基本", content: "HTMLの構造とCSSによる装飾を紹介します。" },
      { title: "サイト内検索の作り方", content: "JavaScriptで簡単な検索機能を作ってみましょう。" },
      { title: "React入門", content: "コンポーネントベースの開発を学びます。" }
    ];

    function searchArticles() {
      const query = document.getElementById("searchBox").value.trim().toLowerCase();
      const resultsDiv = document.getElementById("results");
      resultsDiv.innerHTML = "";

      if (!query) {
        resultsDiv.innerHTML = "<p>キーワードを入力してください。</p>";
        return;
      }

      const matched = articles.filter(article =>
        article.title.toLowerCase().includes(query) ||
        article.content.toLowerCase().includes(query)
      );

      if (matched.length === 0) {
        resultsDiv.innerHTML = "<p>一致する記事が見つかりませんでした。</p>";
        return;
      }

      matched.forEach(article => {
        const div = document.createElement("div");
        div.className = "result";
        div.innerHTML = `<h2>${article.title}</h2><p>${article.content}</p>`;
        resultsDiv.appendChild(div);
      });
    }
    